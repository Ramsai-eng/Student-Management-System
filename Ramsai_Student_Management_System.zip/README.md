# Student Management System (Java)

A beginner-friendly console application demonstrating Java classes, encapsulation, collections, loops, conditionals, and input validation.

## Features
- Add a student record
- View all records
- Search by student ID
- Delete a record by ID
- Validate duplicate IDs and marks range

## Requirements
- Java 17 or later (uses switch arrow syntax)

## Run
1. Open a terminal in this folder.
2. Compile: `javac StudentManagementSystem.java`
3. Run: `java StudentManagementSystem`

## Limitations
Records are stored in memory and are cleared when the program exits. Database/file persistence can be added as a future improvement.

Before listing this project on a resume, run it yourself, test the features, and make sure you can explain the code.
